var imgCtrlId = 0, 
btnCtrlId = 0, 
txtContentCtrlId = 0;
var timeOutVar; // variable to debounce the request
var detachedElements; // variable to store the deleted components from the ui builder
$(document).ready(function(){
    /* code to allow the dropping of the components from the components or image library */
    allowDrop = function(e){
        e.preventDefault();
    }
    
    /* code to drag the specific components from the components or image library */
    drag = function(e, controlType){
        e.dataTransfer.setData('controlType', controlType);
        if(controlType == "image"){
            e.dataTransfer.setData('imageURL', e.target['src']);
        }
    }
    
    /* code to handle the dropping of the dragged components from the component or image library */
    drop = function(e){
        e.preventDefault();
        var controlType = e.dataTransfer.getData('controlType');
        switch(controlType){
            case 'image': 
            var imageSrc = e.dataTransfer.getData('imageURL');
            var elem = document.createElement("img");
            var elemWrapper = document.createElement("div");
            elem.setAttribute("src", imageSrc);
            elem.setAttribute("width", "95%");
            elem.setAttribute("height", "95%");
            elemWrapper.style.width = "150px"; elemWrapper.style.height = "100px";
            elemWrapper.setAttribute("class", "draggable ui-widget-content");
            elemWrapper.setAttribute("data-img-id", "img-"+imgCtrlId);
            elemWrapper.setAttribute("data-comp-cat", "image");
            //elemWrapper.setAttribute("id", "");
            elemWrapper.append(elem);
            e.target.append(elemWrapper);
            $(elemWrapper).draggable({ containment: "#ui-builder-container", scroll: false }).resizable({containment: "#ui-builder-container",
             animate: true, 
             maxHeight: 250,
             maxWidth: 350,
             minHeight: 150,
             minWidth: 200});
            $(elemWrapper).bind('click', selectComponent);
            imgCtrlId++;
            break;
            case 'text':
            var elem = document.createElement("p");
            var elemWrapper = document.createElement("div");
            elem.style.width = "100%";
            elem.style.padding = "10px 15px";
            elem.style.wordWrap = 'break-word';
            elem.style.fontSize = '14px';
            elem.style.fontFamily = 'Georgia, Helvetica, Arial, sans-serif';
            elem.style.lineHeight = "22px";
            elem.innerHTML = "Lorem ipsum Lorem ipsum";
            elemWrapper.style.width = "200px";
            elemWrapper.style.padding = "5px 15px";
            elemWrapper.setAttribute("class", "draggable ui-widget-content");
            elemWrapper.setAttribute("data-txt-id", "txt-"+txtContentCtrlId);
            elemWrapper.setAttribute("data-comp-cat", "txt");
            //elemWrapper.setAttribute("id", "");
            elemWrapper.append(elem);
            e.target.append(elemWrapper);
            $(elemWrapper).draggable({ containment: "#ui-builder-container", scroll: false }).resizable({containment: "#ui-builder-container", animate: true, 
            maxHeight: 400,
            maxWidth: 500,
            minHeight: 100,
            minWidth: 150});
            $(elemWrapper).bind('click', selectComponent);
            txtContentCtrlId++;
            break;
            case 'button': 
                var elem = document.createElement("button");
                var elemWrapper = document.createElement("div");
                elem.style.width = "100%"; elem.style.padding = "10px 20px";
                elem.style.backgroundColor = "#173c62";
                elem.style.border = "1px solid #173c62";
                elem.style.color = "#fff";
                elem.style.padding = "10px 15px";
                elem.style.marginBottom = "10px";
                elem.style.fontFamily = 'Georgia, Helvetica, Arial, sans-serif';
                elem.style.lineHeight = "22px";
                elem.innerHTML= "Save";
                elemWrapper.style.width = "150px"; elemWrapper.style.padding = "10px 20px";
                elemWrapper.setAttribute("class", "draggable ui-widget-content");
                elemWrapper.setAttribute("data-btn-id", "btn-"+btnCtrlId);
                elemWrapper.setAttribute("data-comp-cat", "btn");
                //elemWrapper.setAttribute("id", "");
                elemWrapper.append(elem);
                e.target.append(elemWrapper);
                $(elemWrapper).draggable({ containment: "#ui-builder-container", scroll: false }).resizable({containment: "#ui-builder-container", animate: true, 
                maxHeight: 140,
                maxWidth: 500,
                minHeight: 120,
                minWidth: 150});
                $(elemWrapper).bind('click', selectComponent);
                btnCtrlId++;
                break;
        }
        
    }

    /* code to display the properties of selected components in the ui builder canvas */
    selectComponent = function(){
        var selectedComp = $(this);
        var selectedCompType = $(selectedComp[0]).attr('data-comp-cat');
        $('.ui-builder-prop-container').html('');
        switch(selectedCompType){
            case 'image':
              $(selectedComp[0]).addClass('selectedComp');
              var selectedCompId = $(selectedComp[0]).attr('data-img-id');
              var imageIdContainer = document.createElement('div');
              imageIdContainer.setAttribute("class", "prop-settings-grp");
              var imageIdLabel = document.createElement('label');
              imageIdLabel.innerHTML = 'ID';
              imageIdLabel.setAttribute("class", "prop-settings-label");
              var imageIdInput = document.createElement('input');
              imageIdInput.setAttribute("type", "text");
              imageIdInput.setAttribute("data-prop-img-id", selectedCompId);
              imageIdInput.setAttribute("class", "prop-settings-input");
              imageIdContainer.append(imageIdLabel);
              imageIdContainer.append(imageIdInput);
              $(imageIdInput).bind('keyup', function(selectedCompId){
                clearTimeout(timeOutVar);
                var currElem = $(this);
                var imgId = $(this).data('prop-img-id');
                timeOutVar= setTimeout(function(){setCompId(imgId, currElem, "image")}, 1000);
              })
              var imageUrlContainer = document.createElement('div');
              imageUrlContainer.setAttribute("class", "prop-settings-grp");
              var imageUrlLabel = document.createElement('label');
              imageUrlLabel.innerHTML = 'Image URL';
              imageUrlLabel.setAttribute("class", "prop-settings-label");
              var imageUrlInput = document.createElement('input');
              imageUrlInput.setAttribute("type", "text");
              imageUrlInput.setAttribute("value", $(selectedComp[0]).find('img').attr('src'));
              imageUrlInput.setAttribute("data-prop-img-url-id", selectedCompId);
              $(imageUrlInput).bind('keyup', function(selectedCompId){
                clearTimeout(timeOutVar);
                var currElem = $(this);
                var imgUrlId = $(this).data('prop-img-url-id');
                timeOutVar= setTimeout(function(){setImageUrl(imgUrlId, currElem, "image")}, 1000);
              })
              imageUrlInput.setAttribute("class", "prop-settings-input");
              imageUrlContainer.append(imageUrlLabel);
              imageUrlContainer.append(imageUrlInput);
              $('.ui-builder-prop-container').append(imageIdContainer);
              $('.ui-builder-prop-container').append(imageUrlContainer);
              break;

              case 'txt':
                $(selectedComp[0]).addClass('selectedComp');
                var selectedCompId = $(selectedComp[0]).attr('data-txt-id');
                var txtIdContainer = document.createElement('div');
                txtIdContainer.setAttribute("class", "prop-settings-grp");
                var txtIdLabel = document.createElement('label');
                txtIdLabel.innerHTML = 'ID';
                txtIdLabel.setAttribute("class", "prop-settings-label");
                var txtIdInput = document.createElement('input');
                txtIdInput.setAttribute("type", "text");
                txtIdInput.setAttribute("data-prop-txt-id", selectedCompId);
                txtIdInput.setAttribute("class", "prop-settings-input");
                txtIdContainer.append(txtIdLabel);
                txtIdContainer.append(txtIdInput);
                $(txtIdInput).bind('keyup', function(selectedCompId){
                  clearTimeout(timeOutVar);
                  var currElem = $(this);
                  var txtId = $(this).data('prop-txt-id');
                  timeOutVar= setTimeout(function(){setCompId(txtId, currElem, "txt")}, 1000);
                })
                var txtContentContainer = document.createElement('div');
                txtContentContainer.setAttribute("class", "prop-settings-grp");
                var txtContentLabel = document.createElement('label');
                txtContentLabel.innerHTML = 'Content';
                txtContentLabel.setAttribute("class", "prop-settings-label");
                var txtContentInput = document.createElement('textarea');
                txtContentInput.value = $(selectedComp[0]).find('p').html();
                txtContentInput.style.resize = 'none';
                txtContentInput.setAttribute("data-prop-txt-content-id", selectedCompId);
                $(txtContentInput).bind('keyup', function(selectedCompId){
                    clearTimeout(timeOutVar);
                    var currElem = $(this);
                    var txtContentId = $(this).data('prop-txt-content-id');
                    console.log(txtContentId);
                    timeOutVar= setTimeout(function(){setTxtContent(txtContentId, currElem, "txt")}, 1000);
                })
                txtContentInput.setAttribute("class", "prop-settings-input");
                txtContentContainer.append(txtContentLabel);
                txtContentContainer.append(txtContentInput);
                $('.ui-builder-prop-container').append(txtIdContainer);
                $('.ui-builder-prop-container').append(txtContentContainer);
                break;

                case 'btn':
                $(selectedComp[0]).addClass('selectedComp');
                var selectedCompId = $(selectedComp[0]).attr('data-btn-id');
                var btnIdContainer = document.createElement('div');
                btnIdContainer.setAttribute("class", "prop-settings-grp");
                var btnIdLabel = document.createElement('label');
                btnIdLabel.innerHTML = 'ID';
                btnIdLabel.setAttribute("class", "prop-settings-label");
                var btnIdInput = document.createElement('input');
                btnIdInput.setAttribute("type", "text");
                btnIdInput.setAttribute("data-prop-btn-id", selectedCompId);
                btnIdInput.setAttribute("class", "prop-settings-input");
                btnIdContainer.append(btnIdLabel);
                btnIdContainer.append(btnIdInput);
                $(btnIdInput).bind('keyup', function(selectedCompId){
                  clearTimeout(timeOutVar);
                  var currElem = $(this);
                  var txtId = $(this).data('prop-btn-id');
                  timeOutVar= setTimeout(function(){setCompId(txtId, currElem, "btn")}, 1000);
                });
                var btnLblContainer = document.createElement('div');
                btnLblContainer.setAttribute("class", "prop-settings-grp");
                var btnLabel = document.createElement('label');
                btnLabel.innerHTML = 'Button Label';
                btnLabel.setAttribute("class", "prop-settings-label");
                var btnLblInput = document.createElement('input');
                btnLblInput.setAttribute("type", "text");
                btnLblInput.setAttribute("value", $(selectedComp[0]).find('button').html());
                btnLblInput.setAttribute("data-prop-btn-lbl-id", selectedCompId);
                $(btnLblInput).bind('keyup', function(selectedCompId){
                    clearTimeout(timeOutVar);
                    var currElem = $(this);
                    var btnLblId = $(this).data('prop-btn-lbl-id');
                    timeOutVar= setTimeout(function(){setBtnLbl(btnLblId, currElem, "btn")}, 1000);
                })
                btnLblInput.setAttribute("class", "prop-settings-input");
                btnLblContainer.append(btnLabel);
                btnLblContainer.append(btnLblInput);
                $('.ui-builder-prop-container').append(btnIdContainer);
                $('.ui-builder-prop-container').append(btnLblContainer);
                break;            
        }
    }

    /* code to delete the components from the ui builder canvas */
    deleteSelectedComp = function(){
        detachedElements = $('.selectedComp').detach();
    }

    /* code to undo or restore the deleted components in the ui builder canvas */
    undoSelectedComp = function(){
        if(detachedElements){
            detachedElements.appendTo('#ui-builder-container');
            detachedElements = null;
        }
    }

    /* code to set the component id of specific component using properties panel */
    setCompId = function(compId, currElem, compType){
        switch(compType){
            case "image":
                $('[data-img-id="'+compId+'"]').attr('id', currElem[0].value);
                break;
            case "txt":
                $('[data-txt-id="'+compId+'"]').attr('id', currElem[0].value);
                break;
            case "btn":
                $('[data-btn-id="'+compId+'"]').attr('id', currElem[0].value);
                break;
        }
    }

    /* code to set the image url of specific image component using properties panel */
    setImageUrl = function(compId, currElem){
        $('[data-img-id="'+compId+'"]').find('img').attr('src', currElem[0].value);
    }

    /* code to set text content of specific text component using properties panel */
    setTxtContent = function(compId, currElem){
        $('[data-txt-id="'+compId+'"]').find('p').html(currElem[0].value);
    }

    /* code to set button label of specific button component using properties panel */
    setBtnLbl = function(compId, currElem){
        $('[data-btn-id="'+compId+'"]').find('button').html(currElem[0].value);
    }

    /* code to export the html built using ui builder */
    download = function(){
            var a = document.body.appendChild(
                document.createElement("a")
            );
            a.download = "export-ui.html";
            var doc = document.implementation.createHTMLDocument("New Document");
            var containerElem = document.createElement('div');
            containerElem.setAttribute("class", "ui-comp-container");
            containerElem.innerHTML = document.getElementById("ui-builder-container").innerHTML;
            containerElem.style.width = "620px";
            containerElem.style.margin = "0 auto";
            containerElem.style.padding = "10px 15px";
            doc.body.append(containerElem);
            a.href = "data:text/html," + new XMLSerializer().serializeToString(doc);
            a.click();
    }
})
